
import './App.css';
import SketchBoard from './components/SketchBoard';
import SketchingBoardComponent from './components/SketchingBoardComponent';

function App() {
  return (
    <div className="App">
      <SketchBoard />
      {/* <SketchingBoardComponent /> */}
    </div>
  );
}

export default App;
