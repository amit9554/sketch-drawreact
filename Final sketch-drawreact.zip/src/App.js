
import './App.css';
import SketchBoard from './components/SketchBoard';

function App() {
  return (
    <div className="App">
      <SketchBoard />
    
    </div>
  );
}

export default App;
